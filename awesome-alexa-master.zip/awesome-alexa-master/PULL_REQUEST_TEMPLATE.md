Changes proposed in this pull request

-
-
-

„Be quick, but don't hurry“ - John Wooden
@GetStoryline/awesome-alexa/
